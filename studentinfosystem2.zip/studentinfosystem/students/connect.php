<?php 

	$host = "localhost";
	$username = "root";
	$password = "";
	$db_name = "studentinfosystem";

	$con = mysqli_connect('localhost','id19462926_augustoantenucci','zm&KGHAxXG2Arj7','id19462926_studentinfosystem');

	if(!$con) {
		die("Cannot connect to the database");
	}

?>