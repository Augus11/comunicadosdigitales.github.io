<?php
$con  = mysqli_connect('localhost','id19462926_augustoantenucci','zm&KGHAxXG2Arj7','id19462926_studentinfosystem');
if(mysqli_connect_errno())
{
    echo 'Database Connection Error';
}
