<?php 

  session_start();

  require '../connect.php';
  require '../functions.php';
 

  if(isset($_SESSION['adminName'], $_SESSION['password'])) {

 if( $_SERVER['REQUEST_METHOD'] == 'GET') {
    $name = $_GET["name"];
    $course = $_GET["curso"];
?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Retiros - Colegio Preuniversitario Escobar</title>

    <link href="../css/custom.css" rel="stylesheet">
	<link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/styles.css" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oxygen&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

    <!--google material icon-->
    <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body>

  




    <div class="wrapper">


        <div class="body-overlay"></div>


        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3><img src="https://www.colegioubaescobar.gob.ar/wp-content/uploads/2020/07/cropped-WhatsApp-Image-2020-02-10-at-11.45.15.jpeg"  /><span></span></h3>
            </div>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="../home.php" class="dashboard"><i class="material-icons">dashboard</i><span>Inicio</span></a>
                </li>
                


                <a href="calificaciones.php">
                    <li class="dropdown">
                        <i class="material-icons">domain_verification</i><span>Calificacionnes</span></a>
                    </li>
                </a>

                <a href="../autorized.php">
                    <li class="dropdown">
                            <i class="material-icons">library_books</i><span>Autorizados a retirar</span></a>
                    </li>
                </a>

                <a href="../Events/eventos.php">
                    <li class="dropdown">
                            <i class="material-icons">event</i>

                            <span>Eventos</span></a>
                    </li>
                </a>




                <li class="dropdown">
                    <a href="../profile.php" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="material-icons">account_circle</i><span>Cuenta</span></a>
                    <ul class="collapse list-unstyled menu" id="pageSubmenu5">
                        <li>
                            <a href="profile.php">Mi cuenta</a>
                        </li>
                        <li>
                            <a href="editprofile.php">Editar Usuario</a>
                        </li>
                        <li>
                            <a href="changepassword.php">Cambiar Contraseña</a>
                        </li>
                    </ul>
                </li>

            </ul>


        </nav>



        <!-- Page Content  -->
        <div id="content">

            <div class="top-navbar">
                <nav class="navbar navbar-expand-lg">
                    <div class="container-fluid">

                        <button type="button" id="sidebarCollapse" class="d-xl-block d-lg-block d-md-mone d-none">
                            <span class="material-icons">arrow_back_ios</span>
                        </button>


                        <div>
                        </div>
                        
                        <div class="welcome"><?php echo "<a href='profile.php' style='font-size:20px;'>".$_SESSION['adminName']."</a>";?></div>

                        <div>
                        <p style='font-size:20px; margin-top:10px; color:white;'>ㅤㅤ</p>
                        </div>

                        <a href="../logout.php" style='font-size:18px; color:white; margin-left:40px;'>Cerrar sesión<span class="glyphicon glyphicon-off" aria-hidden="true"></span></a>

                        <button class="d-inline-block d-lg-none ml-auto more-button" type="button"
                            data-toggle="collapse" data-target="#navbarSupportedContent"
                            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="material-icons">more_vert</span>
                        </button>

                        <div class="collapse navbar-collapse d-lg-block d-xl-block d-sm-none d-md-none d-none"
                            id="navbarSupportedContent">
                            <ul class="nav navbar-nav ml-auto">
                                
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>


            <div class="main-content" style=" margin:0 auto;">

                <div class="row">
                        
                    </div>
                        <div class="card card-stats" style="background-color: rgb(221, 221, 221); width: 1400px; height: auto;">   
                            <div>
        <div align="center">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABU1BMVEX///+RtDYAmtpYWVvamDe6AH364CkOV4xVVlhOT1FQUFOsrK9RUlSlpabd3d3y8vLDw8RvcHJKS00Altnk5ORiY2X///zs7OyOsi1/gIK3AHbFxcW5uruVlpg/Pz+Oj5LPz9CKsCJ2d3men6BpaWnZlCQAk9kAS4WBgYG0tLT44BS1AHDcnT/47+D44AD+/fE1bpvr9vuRze344zIARoPB1pezzHyqxmr04sngrGTpuYLhp1f79u/sxZfbkR3szKPpttHflMT67/XNY6TxyuLVebPx1Oby3MD99s/77Yv9++bcncL35PT776PJQJjhq8z852PXg7b69LPgqlz563zQV6D35VXCztzV4uusv9F6mLj7+dn79sKTqcC/HI3O6Pis2vJvwOVTrt1dsuJSe6Pb7/fl7dLS4bN5mrfY6MGZuUjL2eKhwF7D15YYX5AAodkuLi/firkWAAAODklEQVR4nO2a/V/TRhzHr7RAImnTpmla+/wEhSJEwBYR5hQ3B0wcc4pPcyBKOyqM/f8/7b53l+SSFtq5QYKv+7jXSzyS7N75Pl+LkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkNDN1YbfG7hi3V+788DwexNXJwPdn45Epte/YcQNDIgR1/zex9XptwjR9Hd+b+RqZKDvpilh5OF9vzdzNbpvAWJ9kxnVWHcAv81Q/J4zYeTh935v57/p0eNHm961DR4QW/FGh+KTbHZ+/IkH8oGbMHLnBofiD9lxUHb8x6fO4k8ewEjEG4pb29s717rPr9fP40zZ7PjjZ3Rt444XMDLNh6K5u7LYbDZvCOKP446y889/2eRLIZ9tFqw7zO1mcwKruevnvkfX8+w4r+z4JloYABiJrNNQNHcpH9aez1sfUeNuZX9FaG0QYGT6J3y18WLF4puYWLkZTXnWg7jp6mYcJ/0NvJTnw256MwJx3m3Cxwit9/NNR8CA7118mHDL782Pos35PhM+7AdcwzFovlyccKv5wu/djyIP4Y/20OStFC88BgTCbb93P5JchNlnAxLpHRyB5l4fH9ZLvzc/klyEr3C/NshDtyYGAU7s+735kcQTZn9AC15AmPC3vRFolQvT792PIle1QN52BkJwsIeCFoNeLt68fuMixKXCcHekUOXf7w8AxF3pItbvfiNcrC9v392dnLz31tXT4DzjLhUEsB9usbn/cvfF71s7ZiC91DDefLh7r9FoTE5ONj64CL15BgC3Ft10K3u7v5ueB2L5BDNY7+4BHFHjT4T+cEz4MzJcZxcA2HThbW8xuqWl44PDw2WiQ6yD46Ulf7Ecfbg36egdP1tkn7paUsiiHGBzYnuLmGrp4PDj0flYcibJa2Zm7PzTIQqCMd81HMDGOzjEsAifu510zRWDi9vEegfLR2OYZ2yQ8Pqy33SgDxzh5GeEfrUIs7hj4zLpnQ20s2LVveYe1IXj5bGZC+gY45HfdKDXPOFdhH62CR/xHRucrjllArfYxsHRpXTBIUxP8lLRL7aXPuUPoB4gtMvSaHPlPY6+TzND8IAwEF6KPnOADR09tds2PgynF9AOs2BzH0fg4dgw+4FmgpFPeTdtvHbGp+fc7DuNTfiSEjb3cH78OApfQJwU6y5H+MEuiDjROIeIDxfQewa4jwGPRvBQMOGB32hMX5yKyJWL7C9colmzTThhjgaYPD8aG/ObzNZnx0/vGuhxti+V4nbNpIC4tzZGcNHk+aGBW4Eg1HtkdPBM4RA2luxj/UdcR7OBdumhL57iD4dbMHm+hB9sokC0NN1KC6E/nc4Up5r+cojzzD6Nwh10PIIFx5bQSaVSOfEbjqibqXSQ+hffe7/yEuKx1yS1EI6ajkYgPMaAoVCoEohhqlPJ9Ay+YiAWiDzhAhuamu/R8XAfnTlEnRCo0vWbDmSEQpk256f33qCnWW8uXUAvmqRS4Eo43IIfkXGaAcJMy286otUMeddWUYSK+JwQ/oo2nKZ7mxDuIjQc8ByhVoXYMBMIG+JUg7eCQ5FrvqmbvrJ7mnWDVkPspAfDnDQ5dow9P0S9NBipZgc7FITiF+anjS/o2TzrS9dsQnq8ZqLlYXkGB6ERYgpGpkEIYiazitDbht3W0Gz6zPoCxrpJbbiC0KchFpzB00Q7QwEzp36jMXVJYm875xkqnS/gOHjaFYf7w2pFEmcZ+rzgpFIsk7zyypmFCLnmiXvG36C5dA+h88tNeGTYQYgVhI6GaJUitixHxZ3bJhuf6Im3VQ9fDiGEacm0+QJSK0DsrQPil7uYsfEZkUkfuyn7wuX3yGgOJ4Ru1OzZhKGA5BlQj6YGiMWlP+/Ro288Q2WfsG8Kwfy7d4mXJmdsC55mbBOe+Y3F6cSqX6v4tX/5qwHJBs5Ns8+sok8DETLNoPRyfo4RZz4ZGNAJwkyATIgMy7UyGajRbyfv4bKvjmezr9g39mA+XKHVIunFO4JB/vgoeYjdPWRbkPh8gHRiv/pKG179279wKG7+kZ3/AVd9QFxHZEDccVf8ZHLs4zGCTyqQgf8+yTiAAUqkRAYXPpkWTK6v3xpo8xV8XYj46cP7YMTmFjpwCGeSnw6X8KUn7d4pNr3ZrnB8gamFlrgiFqqEWlYIPZ7HyYaU/d8QerFod97wsQTBQ2a3V8mEMhjI5A0YmHbGUdu1v0q7Q5efPX+MESPT5HOnPThnW56ZSY4dLdNTtE47w15Nzyqr7C11fGQZLIN3MWDsdZ1cuPBgbX19A/vp/nu0dHhAj3mNzlmo4kCZ6IxLM22/OC5R140IkKetjkPp+tDT7HTbvQp/R8/tBkGqFLZ4J7NMUQmdnnU7O9x+jZ3OSWsV07mvxrXBcLqZgMyFXplePmrJDMD0eqerWKe9Hjatlw6QTg3OCQLpoyA+nw4gBV3wu0qbHykyPb9JLlTrMsSLVemdQM/AJ53Aqn2BkS4RrhZd3NGcOS8nE7xCwYlrnEfk62E+dNJz7gtcM+OW0fsXVsRJaBXstbPKvZeAA+KEOjJiJtMjzV2nzafWwAO6RthL+XotMJ/ZPeX5MgE5Ar5c5kixCOmEtG3u1WBWeq+MdmUglJul1V0NeSp/JhT0717a6mtRByH2NTaV1WDNvJeq829SKiO+ESHoyBzFU90GDHSdH6QOV8SH890wA1IZ3Ysa7X6+1g2KQF5Gy1MMBilDT3VuKKK3oA8wX2X1JMCTxEjqtGCeH4SJR+HT7o2pgJfKJGcywGkJ/uU6xPkWBMczZ22is+7JNwYnJCQkJCQkdJliuVxZ9XsTV6l8UZa1qt+7GKRcnFf6q58zdSsclhL/48b+L83hV+9IK331gwJLGMUbcyTNfvWDBKFvooTfvJem8jmmr0/3gSaUUv1g6ZjuXlR174p7wSLEN3of1Xcnvd173RVpIKF+WwNJBat4xEoyWQkXrG3lE0VySc26hBLOSXixeDtmPUnNV8mN2q2StRavVVN5FLuFn3aVYLYGEeY0hSYeRaMLBWshrBTLsKDXNcm6ZI5eA4RhiV4nWYt6WJasO7UpClhUJCkRg3Xt66vvfyPUZTu3UsLbzkJYjuKFdFhyVhjNlCspazm6KPetxTT4OQUP0K6lyaOZJlemIv/LgkLMoGmyTFLrnEZtgKXQ9161riAmk3WHEJwZNi9J9GVpYYn4N1mrw1KaQSuKcn1ealcLWizqeDsS/kmNzxJiYi8ZIjBW0PKImUFKxZBagO0qJYcwryK9CjfI1LJRrQqdoJ6ANQVehUr9WC5M3c5fI6FV8KvWFuScfUWZUBS4e4iRqYvNEnwVuaoFuKBVOFio6fBSZEg2KnHQ8DUlUjSQkGywam+hdssbMsTItPspw8412DlHGIU3oLiCTHUTytdjProbQqgwLyXbJnaRlNkyvQL+KaX43abC9h5VxfqZIyRWl63qoJenaoWS5CaMXwscESWcy1MRn4prLFRSZfgnhJB0m7slLTluTParQB3gCKlLkptRvI7fnqLQWPaN0FsPC6zY0bJmJR5buuQAkN8qUEE4wrRDOEsfJQWMEMVTrFAX9QE21DkbosttGCVZVw7XE/56aX9fqsYTtAjWcPGTrFLGlA5zcSgNiMOYlVZIfpESuMx6M43vhFhlkm9w6imR2sD/ingmLR8ERisjF2Ge1Bcc03H4QYKHB5GQVD0oH2S/rvROE6N9UTgMCYpUfBp8xK+hYamxR+DfKlZV8SmXFmpMsIdYYg4Tq8RSJavNUiDu1HgVcg+pBhI0PCTt0tLIurYcUkkBBf8mhISfNn5+EipMMmw2pchKokqaa9Isz9LuM1VNKLJUhF3WSQ8mVesEnhqOdd4ymy806BjmyKsIV1O0FyXZySdCu6mZhdnJTu+00KsKy/iEC+pGjFVM1rEih9CaOWjPrhet6wg1ybnXT6hwgISwXLRHOoW2bjHJnvIkDWofbtYUe4GVSiCU81VmLdaVsrlLKs5BwBLsa+/a8hpuOOA/+KMQe5SrEunhpJKdgKIp2tdJCfby1RKdR5SE1aLnZEWuQ+qBVbtPL5H76mXsGVK4Tq6t4hbH6heuRWmdF1srx/Nx94cQsXI+n4txQ7kay+FruBEhHSOdaDqXz3GXpcv5OFnX7bOaWCx2LcO9kJCQkNCVKJ12/a3S9M4Kgs6vqXa6ZzWCu86uOdbFiHwAcBUb/teqF8k+9CL9sLpAOmqVdKJI/Zv0LiXawUTZx9l6SktJRdIF6H+TlXQR1/MiPUpkF6OyIqc0yT7p91EJmZ5EyXSir5ENqgol1MgUWKDdSpReoWo1bCZav/UiWUrDkXGOvpUCJdSL0I/WigEo8/UaUJSVkovwFiWUS3CM7SaMckdwPCEKE7MyQva4eu2Ktz+C6rko7ixTU1PUB92Eml4veQmrUedmnlCln98wwjBts/nX4ZfqcaTk85IVZW7CYlrH+3YTprgRwSaMzs2FWSBTQuLeeFpWrnr/w4UJ82El7iGULUIUlTyE9UGEpUKBDSAWIR0/8tJV73+4MCFKJOxMWXBlGkgUqZqb8Db3aYYrDhH3AFSnvlwIwNeJgBBqGCOMkjE2RnMgIYzJdRfhnOzcfDHhFD0pkK5x6r1IltMxQr1Y0tVymBUGAhotughRql5O61NRejVZSRf7CNVwNaaWEwFINKjK5vUp9q0afVaRwyxdqhLZeYKm/DnrlL+GR/0qnXBpIklLDmGNObFakGQpALVCSEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISEhISOh/1j/L69sEs7bFnwAAAABJRU5ErkJggg=="
                height="100" width="100" alt="" style="margin-right: 60px;" border="1">
    
            <img src="https://www.colegioubaescobar.gob.ar/wp-content/uploads/2020/07/cropped-WhatsApp-Image-2020-02-10-at-11.45.15.jpeg"
                height="85" width="75" alt="" style="margin-right: 60px;" border="1">
    
            <img src="https://bicentenario.uba.ar/wp-content/uploads/2021/12/identidad-visual-uba-logo.jpg" height="100"
                width="100" alt="" style="margin-right: 60px;" border="1">
    
        </div>
    
        <div align="center" style="margin-bottom: 25px; margin-top: 15px;">
            <table style=" width: 1000px; border: 2px solid; border-collapse: collapse;">
                <tr>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; font-weight: bold; font-family: 'Roboto', sans-serif;">
                        Boletín Trimestral -
                        Año 2022</td>
                </tr>
            </table>
        </div>
    
        <div align="center" style="margin-bottom: 25px;">
            <table style="width: 1000px;border: 2px solid; border-collapse: collapse;">
                <tr>
                    <td colspan="4" align="center"
                        style=" padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                        Colegio
                        Preuniversitario Dr. Ramón A. Cereijo</td>
                </tr>
    
                <tr>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                        Estudiante:</td>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;"> <?php echo "<h6> " . $_GET["name"] . "</h6>"; ?> </td>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                        Curso:</td>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;"> <?php echo "<h6> " . $_GET["curso"] . "</h6>"; ?> </td>
                </tr>
            </table>
        </div>
    
    
    
        <div align="center" style="margin-bottom: 25px;">
            <table style="width: 1000px; border: 2px solid; border-collapse: collapse;">
                <tr>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse; font-weight: bold; font-family: 'Roboto', sans-serif;"
                        rowspan="2">ASIGNATURAS
    
                    </td>
    
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;"
                        colspan="4">NOTAS
                        FINALES
                <tr>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                        1er Trimestre</td>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                        2do Trimestre</td>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                        3er Trimestre</td>
                    <td align="center"
                        style="padding-top: 5px; padding-bottom: 5px; border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                        PROMEDIO FINAL</td>
                </tr>
                </td>
                </tr>
    
                <tr>
                    <form method="POST">
                    <td align="left" style="border: 2px solid; border-collapse: collapse; padding-top: 5px; padding-bottom: 5px; font-family: 'Roboto', sans-serif;">
                        <select name="materia" class="form-control" style="width: 270px; margin:15px; ">
                            <?php
                            require '../connect.php';
                            $getCourses1 = "SELECT * FROM materias order by id";
                            $getCourses2 = mysqli_query($con, $getCourses1);

                            while($row = mysqli_fetch_array($getCourses2)) {
                                $nombre = $row['nombre'];

                                ?>
                                <option value="<?php echo $nombre;?>"><?php echo $nombre;?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </td>
    
                    <td align="center" style="padding-top: 5px; padding-bottom: 5px;border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif; width:200px"> <input style="text-align:center;" name='mark' id='mark' class='form-control col-md-6' type='text'/></td>
                        
                    <td align="center" style="padding-top: 5px; padding-bottom: 5px;border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;"> <input style="text-align:center;" name='mark' id='mark' class='form-control col-md-6' type='text'/></td>
                        
                    <td align="center" style="padding-top: 5px; padding-bottom: 5px;border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;"> <input style="text-align:center;" name='mark' id='mark' class='form-control col-md-6' type='text'/></td>
                    
                    <td align="center" style="padding-top: 5px; padding-bottom: 5px;border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;"> <input style="text-align:center;" name='mark' id='mark' class='form-control col-md-6' type='text'/></td>
                </tr>
    
                </form>
            </table>
    
            <div align="center" style="margin-bottom: 25px; margin-top: 25px;">
                <table style="width: 1000px; border: 2px solid; border-collapse: collapse;">
                    <tr>
                        <td align="center"
                            style="padding-top: 5px; padding-bottom: 5px; font-family: 'Roboto', sans-serif; width: 200px; font-weight: bold;">
                            Inasistencias
                        </td>
    
                        <td align="center"
                            style="padding-top: 5px; padding-bottom: 5px;border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                            9</td>
                        <td align="center"
                            style="padding-top: 5px; padding-bottom: 5px;border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                            3</td>
                        <td align="center"
                            style="padding-top: 5px; padding-bottom: 5px;border: 2px solid; border-collapse: collapse;font-weight: bold; font-family: 'Roboto', sans-serif;">
                            4</td>
                    </tr>
                </table>
            </div>
        </div>
    
    
        <div style="margin-top: 100px; display: flex; flex-direction: row; justify-content: center; align-items: center;">
            <div style="padding-right: 400px;">
                <hr width="300px;" color="black" style="height: 0.1px;">
                <p align="center" style="font-family: 'Roboto', sans-serif; margin: 0; padding: 0;">Lic.
                    Victoria Serruya</p>
                <p align="center" style="font-family: 'Roboto', sans-serif; margin: 0; padding: 0;">
                    Vicerrectora</p>
            </div>
    
            <div>
                <hr width="300px;" color="black" style="height: 0.1px;">
                <p align="center" style="font-family: 'Roboto', sans-serif; margin: 0; padding: 0;">Lic.
                    Prof. Nicolás Gardone</p>
                <p align="center" style="font-family: 'Roboto', sans-serif; margin: 0; padding: 0;">
                    Rector</p>
            </div>
        </div>
    
        <div style="margin-top: 100px; display: flex; flex-direction: row; justify-content: center; align-items: center;">
            <div style="padding-right: 400px;">
                <hr width="300px;" color="black" style="height: 0.1px;">
                <p align="center" style="font-family: 'Roboto', sans-serif; margin: 0; padding: 0;">Lic.
                    Estudiante</p>
            </div>
    
            <div>
                <hr width="300px;" color="black" style="height: 0.1px;">
                <p align="center" style="font-family: 'Roboto', sans-serif; margin: 0; padding: 0;">Lic.
                    Madre/Padre/Tutor-a</p>
            </div>
        </div>
    </div>
                        </div>
                    </div>
                </div>

                <?php
                    }
                ?>

                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <nav class="d-flex">
                                    <ul class="m-0 p-0">
                                        
                                    </ul>
                                </nav>

                            </div>
                            <div class="col-md-6">
                                <p class="copyright d-flex justify-content-end"> &copy 2021 
                                    <a href="#"></a> 
                                </p>
                            </div>
                        </div>
                    </div>
                </footer>

            </div>



        </div>
    </div>








    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.3.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.3.1.min.js"></script>


    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $('#content').toggleClass('active');
            });

            $('.more-button,.body-overlay').on('click', function () {
                $('#sidebar,.body-overlay').toggleClass('show-nav');
            });

        });





    </script>
</body>
</html>

<?php

}

  unset($_SESSION['prompt']);
  mysqli_close($con);

?>