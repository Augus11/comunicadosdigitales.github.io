<?php
session_start();
require '../connect.php';
require '../functions.php';

if(isset($_SESSION['adminName'], $_SESSION['password'])) {
    

    if(isset($_POST['selected'])) {
        $selected = $_POST['selected'];
    }
    else {
        echo "not set";
    }
    
    $selected2 = $_POST['selected2'];
    $mark = $_POST['mark'];

    foreach ($selected as $index => $selecteds) 
    {
        $s_selected = $selecteds;
        $s_selected2 = $selected2[$index];
        $s_mark = $mark[$index];


        $query = "INSERT INTO boletines (nombre,materia,mark) VALUES('4', '4', '2')";
        $query_run = mysqli_query($con, $query);
    }

    if(!$query_run) {
        die("Invalid query.");
    }

    if($query_run) {
        header("Location: courseSelect.php");
        //exit(0);
    }
    else {
        header("Location: ../home.php");
        exit(0);
    }
}

mysqli_close($con);
?>