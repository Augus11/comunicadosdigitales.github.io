<?php
header('location:admins/index.php');
?>