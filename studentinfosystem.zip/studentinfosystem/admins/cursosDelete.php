<?php
require 'connect.php';

if(isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "DELETE FROM courses WHERE id=$id";
    $con->query($sql);
}

echo "<script> window.location.href='cursos.php' </script>";
exit;

?>