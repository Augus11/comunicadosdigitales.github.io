<?php
require 'connect.php';

if(isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "DELETE FROM faltas WHERE id=$id";
    $con->query($sql);
}

echo "<script> window.location.href='faltas.php' </script>";
exit;

?>