<?php
require 'connect.php';

if(isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "DELETE FROM retiros WHERE id=$id";
    $con->query($sql);
}

echo "<script> window.location.href='autorized.php' </script>";
exit;

?>