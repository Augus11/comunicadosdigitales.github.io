<?php
require 'connect.php';

if(isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "DELETE FROM apercibimientos WHERE id=$id";
    $con->query($sql);
}

echo "<script> window.location.href='apercibimientos.php' </script>";
exit;

?>